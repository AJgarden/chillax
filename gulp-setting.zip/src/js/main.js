const a = ['1', '2', '3'];

console.log(a.includes('2'));